import pandas as pd

dataS = ["Kim", "Park", "Lee", "Choi"]
ser = pd.Series(dataS)

print(ser)

dataDF = {"Name": ["Kim", "Park", "Lee", "Choi"], "Age": [20, 23, 21, 26]}
df = pd.DataFrame(dataDF)
print(df)

df.to_excel("dataFrame.xlsx", sheet_name="StudInfo", index=False)
