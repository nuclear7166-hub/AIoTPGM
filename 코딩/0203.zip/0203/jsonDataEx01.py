import pandas as pd

df = pd.read_json("data.json", encoding="utf-8-sig")
print(df.head())
