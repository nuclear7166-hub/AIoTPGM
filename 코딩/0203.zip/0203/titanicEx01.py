import pandas as pd

titanic = pd.read_csv("titanic.csv")
print(titanic)
print(titanic.head(10))
print(titanic.loc[10:20])
print(titanic["Age"])
print(titanic["Age"].max())


print(titanic[["Name", "Age", "Sex"]])

below_20 = titanic[titanic["Age"] < 20]
print(below_20.head())
