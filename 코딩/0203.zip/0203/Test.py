from datetime import datetime

place = input("경기가 열린 곳은? ")
time = input("경기가 열린 시간은? ")
opponent = input("상대 팀은? ")
goals = int(input("손흥민은 몇 골을 넣었나요? "))
assists = int(input("도움은 몇 개인가요? "))
score_me = int(input("손흥민 팀이 넣은 골 수는? "))
score_you = int(input("상대 팀이 넣은 골 수는? "))

news = f"[프리미어 리그 속보 ({datetime.now()})]\n"
news += f"손흥민 선수는 {place}에서 {time}에 열린 경기에 출전하였습니다.\n"
news += f"상대 팀은 {opponent}입니다.\n"

if score_me > score_you:
    news += f"손흥민 선수의 팀이 {score_me}골을 넣어 {score_you}골을 넣은 상대 팀을 이겼습니다.\n"

elif score_me < score_you:
    news += f"손흥민 선수의 팀이 {score_me}골을 넣어 {score_you}골을 넣은 상대 팀에게 졌습니다.\n"

else:
    news += f"두 팀은 {score_me}대 {score_you}로 비겼습니다.\n"

if goals > 0 and assists > 0:
    news += (
        f"손흥민 선수는 {goals}골에 도움 {assists}개로 팀 승리를 크게 이끌었습니다.\n"
    )

elif goals > 0 and assists == 0:
    news += f"손흥민 선수는 {goals}골로 팀 승리에 기여했습니다.\n"

elif goals == 0 and assists > 0:
    news += f"손흥민 선수는 골은 없었지만 도움 {assists}개로 승리에 공헌했습니다.\n"

else:
    news += "아쉽게도 이번 경기에서 손흥민 선수의 발끝은 침묵을 지켰습니다.\n"

print(news)

from gtts import gTTS
import os

tts = gTTS(text=news, lang="ko")
tts.save("news_Son.mp3")
os.system("start news_Son.mp3")
