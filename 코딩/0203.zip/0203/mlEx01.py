from sklearn.datasets import load_iris

iris = load_iris()

for i in range(0, len(iris.data)):
    print(i + 1, iris.data[i], iris.target[i])


print(iris.keys())
print(iris["data"])
print(iris["target"])
print(iris["DESCR"])
print(iris.DESCR)
print(iris.feature_names)
print(iris.target_names)
