import requests
import pandas as pd

url = "https://api.jsonplaceholder.dev/posts"

response = requests.get(url)
response.raise_for_status()  # 요청 실패 시 예외 발생

# JSON 파싱
data = response.json()

# DataFrame으로 변환
df = pd.DataFrame(data)

print(df.head())
