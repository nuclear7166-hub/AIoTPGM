import numpy as np

np.random.seed(0)
x = np.random.rand(5, 6)

print("행렬:\n", x)
print("1. 전체 최댓값:", x.max())
print("2. 각 행의 합:", x.sum(axis=1))
print("3. 각 행의 최댓값:", x.max(axis=1))
print("4. 각 열의 평균:", x.mean(axis=0))
print("5. 각 열의 최솟값:", x.min(axis=0))


import numpy as np

a = np.array([[4, 3, 5, 7], [1, 12, 11, 9], [2, 15, 1, 14]])

print(a)

print(np.sort(a))
print(np.sort(a, axis=0))


a = np.array([42, 38, 12, 25])
j = np.argsort(a)
print(j)
