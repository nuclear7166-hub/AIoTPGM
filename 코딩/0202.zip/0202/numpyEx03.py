import numpy as np

numpyArray = np.array([[10, 20, 30, 40], [50, 60, 70, 80]])

print(numpyArray)

l1 = list(range(1, 21))
print(l1)
x = np.array(l1)
print(x[x % 3 == 0])
print(x[x % 4 == 1])
print(x[(x % 3 == 0) & (x % 4 == 1)])

a = np.zeros(5)
print(a)
