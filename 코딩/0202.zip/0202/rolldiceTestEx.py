import tkinter as tk
from tkinter import messagebox
import random


class UltimateDiceGame:
    def __init__(self, root):
        self.root = root
        self.root.title("다이스 테마 게이머 🎲")
        self.root.geometry("400x600")

        # 데이터 및 설정
        self.money = 1000
        self.combo = 0
        self.is_dark_mode = False  # 테마 상태
        self.dice_icons = {1: "⚀", 2: "⚁", 3: "⚂", 4: "⚃", 5: "⚄", 6: "⚅"}

        self.setup_ui()
        self.apply_theme()  # 초기 테마 적용

    def setup_ui(self):
        # 상단 설정 바
        self.top_bar = tk.Frame(self.root, pady=5)
        self.top_bar.pack(fill="x")

        self.theme_btn = tk.Button(
            self.top_bar,
            text="모드 변경 🌙",
            command=self.toggle_theme,
            font=("Arial", 9),
        )
        self.theme_btn.pack(side="right", padx=10)

        # 자산 및 콤보 표시
        self.info_frame = tk.Frame(self.root, pady=10)
        self.info_frame.pack(fill="x")

        self.label_money = tk.Label(
            self.info_frame, text=f"내 자산: {self.money}원", font=("Arial", 12, "bold")
        )
        self.label_money.pack(side="left", padx=20)

        self.label_combo = tk.Label(
            self.info_frame, text=f"콤보: {self.combo}", font=("Arial", 12, "bold")
        )
        self.label_combo.pack(side="right", padx=20)

        # 주사위 구역
        self.dice_frame = tk.Frame(self.root)
        self.dice_frame.pack(pady=40)

        self.dice_style = {
            "font": ("Arial", 80),
            "width": 2,
            "relief": "raised",
            "bd": 4,
        }
        self.d1_label = tk.Label(self.dice_frame, text="⚀", **self.dice_style)
        self.d1_label.grid(row=0, column=0, padx=15)
        self.d2_label = tk.Label(self.dice_frame, text="⚀", **self.dice_style)
        self.d2_label.grid(row=0, column=1, padx=15)

        self.label_msg = tk.Label(
            self.root, text="행운을 빕니다!", font=("Arial", 14, "bold")
        )
        self.label_msg.pack(pady=20)

        self.roll_btn = tk.Button(
            self.root,
            text="주사위 던지기 (-100원)",
            font=("Arial", 14, "bold"),
            bg="#3498db",
            fg="white",
            padx=30,
            pady=15,
            command=self.start_game,
        )
        self.roll_btn.pack(pady=10)

    def toggle_theme(self):
        """테마 상태를 반전시키고 적용함"""
        self.is_dark_mode = not self.is_dark_mode
        self.theme_btn.config(
            text="모드 변경 ☀️" if self.is_dark_mode else "모드 변경 🌙"
        )
        self.apply_theme()

    def apply_theme(self):
        """현재 상태에 맞춰 색상을 일괄 변경"""
        bg_color = "#2C3E50" if self.is_dark_mode else "#F8F9FA"
        fg_color = "#ECF0F1" if self.is_dark_mode else "#2C3E50"
        dice_bg = "#34495E" if self.is_dark_mode else "white"

        self.root.configure(bg=bg_color)
        self.top_bar.configure(bg=bg_color)
        self.info_frame.configure(bg=bg_color)
        self.dice_frame.configure(bg=bg_color)

        self.label_money.configure(bg=bg_color, fg="#2ECC71")  # 돈은 항상 초록 계열
        self.label_combo.configure(bg=bg_color, fg="#E74C3C")  # 콤보는 항상 빨간 계열
        self.label_msg.configure(bg=bg_color, fg=fg_color)

        self.d1_label.configure(bg=dice_bg, fg=fg_color)
        self.d2_label.configure(bg=dice_bg, fg=fg_color)

    def start_game(self):
        if self.money < 100:
            messagebox.showwarning("파산", "돈이 부족해요! 1000원을 충전해 드립니다.")
            self.money = 1000
            self.update_display()
            return

        self.money -= 100
        self.update_display()
        self.roll_btn.config(state=tk.DISABLED)
        self.animate(12)

    def animate(self, count):
        if count > 0:
            self.d1_label.config(text=self.dice_icons[random.randint(1, 6)])
            self.d2_label.config(text=self.dice_icons[random.randint(1, 6)])
            self.root.after(60, self.animate, count - 1)
        else:
            self.finish_game()

    def finish_game(self):
        v1, v2 = random.randint(1, 6), random.randint(1, 6)
        total = v1 + v2
        self.d1_label.config(text=self.dice_icons[v1])
        self.d2_label.config(text=self.dice_icons[v2])

        if total == 7:
            self.combo += 1
            bonus = 500 * self.combo
            self.money += bonus
            self.label_msg.config(text=f"결과: {total} - 럭키 7! (+{bonus}원)")
        else:
            self.combo = 0
            self.label_msg.config(text=f"결과: {total} - 꽝입니다!")

        self.update_display()
        self.roll_btn.config(state=tk.NORMAL)

    def update_display(self):
        self.label_money.config(text=f"내 자산: {self.money}원")
        self.label_combo.config(text=f"콤보: {self.combo}")


if __name__ == "__main__":
    root = tk.Tk()
    app = UltimateDiceGame(root)
    root.mainloop()
