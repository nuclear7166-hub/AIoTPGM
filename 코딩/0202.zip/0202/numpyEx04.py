import numpy as np

A = np.array([[1, 2, 3], [4, 5, 6]])
print(A)
print(A.T)


a = np.arange(12)
print(a.reshape(3, -1))
print(a.reshape(2, 2, -1))
print(a.reshape(2, -1, 2))


left = np.zeros((6, 3))
right = np.array([[1, 1], [1, 1], [1, 1], [40, 50], [90, 100], [140, 150]])

middle = np.vstack([np.zeros((3, 2)), np.arange(10, 160, 10).reshape(3, 5)[:, :2]])

top = np.hstack([left, middle, right])

# 아래쪽은 위쪽과 동일
result = np.vstack([top, top])

result

import time

x = np.arange(1, 10001)
y = np.arange(10001, 20001)

start_time = time.time()
z = np.zeros_like(x)

z = np.zeros_like(x)
for i in range(10000):
    z[i] = x[i] + y[i]
z[:10]
print(f"소요 시간 : {time.time() - start_time}초")

start_time = time.time()
z = x + y

print(f"소요 시간 : {time.time() - start_time}초")
