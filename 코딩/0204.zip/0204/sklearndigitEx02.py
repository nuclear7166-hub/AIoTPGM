from sklearn import datasets
import matplotlib.pyplot as plt

# LFW 데이터셋 읽기

lfw = datasets.fetch_lfw_people(min_faces_per_person=70, resize=0.4)

plt.figure(figsize=(15, 5))  # 전체 그림 크기 설정

# 처음 8명의 얼굴 출력
for i in range(8):
    plt.subplot(1, 8, i + 1)
    plt.imshow(lfw.images[i], cmap=plt.cm.bone)
    plt.title(lfw.target_names[lfw.target[i]], fontsize=8)
    plt.axis("off")  # 축 제거

plt.show()


# 20 Newsgroups 데이터셋 읽기

news = datasets.fetch_20newsgroups(subset="train")  # 학습용 데이터

# 0번 샘플 출력
print("***** 0번 뉴스 샘플 *****\n")
print(news.data[0])

print("\n이 문서의 부류는:", news.t)
