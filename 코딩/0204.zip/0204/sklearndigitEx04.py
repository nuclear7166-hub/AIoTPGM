from sklearn import datasets
from sklearn import svm
from sklearn.model_selection import train_test_split
import numpy as np

# 데이터셋 읽기 및 분할

digits = datasets.load_digits()  # 괄호 꼭 필요
x_train, x_test, y_train, y_test = train_test_split(
    digits.data, digits.target, train_size=0.6, random_state=42
)

# SVM 모델 학습

s = svm.SVC(gamma=0.001, C=10)  # gamma와 C 지정
s.fit(x_train, y_train)

# 테스트 집합 예측

res = s.predict(x_test)

# 혼동행렬(Confusion Matrix) 계산

num_classes = 10  # 0~9 숫자
conf = np.zeros((num_classes, num_classes), dtype=int)

for i in range(len(y_test)):
    conf[y_test[i], res[i]] += 1  # 실제(y_test) vs 예측(res)

print("혼동 행렬:")
print(conf)

# 정확률 계산

no_correct = 0
for i in range(num_classes):
    no_correct += conf[i][i]

accuracy = no_correct / len(y_test)
print(f"\n테스트 집합에 대한 정확률은 {accuracy*100:.2f}% 입니다.")
