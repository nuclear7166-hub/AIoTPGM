from sklearn import datasets
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
import numpy as np

# 데이터셋 읽기 & 분할
digits = datasets.load_digits()

x_train, x_test, y_train, y_test = train_test_split(
    digits.data, digits.target, train_size=0.6, random_state=42
)

# Perceptron 학습
p = Perceptron(max_iter=100, eta0=0.001, random_state=42)
p.fit(x_train, y_train)

res = p.predict(x_test)

# 혼동 행렬 계산
conf = np.zeros((10, 10), dtype=int)

for i in range(len(res)):
    conf[y_test[i]][res[i]] += 1  # (실제, 예측)

print("혼동 행렬:")
print(conf)

# 정확도 계산
no_correct = 0
for i in range(10):
    no_correct += conf[i][i]

accuracy = no_correct / len(res)
print(f"테스트 집합에 대한 정확률은 {accuracy*100:.2f}% 입니다.")
