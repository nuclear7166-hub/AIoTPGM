from sklearn import datasets
from sklearn import svm

digit = datasets.load_digits()

# svm 의 분류기 모델 SC 를 학습
s = svm.SVC(gamma=0.1, C=10)
s.fit(digit.data, digit.target)  # digit 데이터로 모델링

# 훈련 집합의 앞에 있는 샘플 3 개를 새로운 샘플로 간주하고 인식해봄
new_d = digit.data[0], digit.data[1], digit.data[2]
res = s.predict(new_d)
print("예측값은 ", res)
print("참값은 ", digit.data[0], digit.data[1], digit.data[2])

# 훈련 집합을 테스트 집합으로 간주하여 인식해보고 정확률을 측정
res = s.predict(digit.data)
correct = [i for i in range(len(res)) if res[i] == digit.target[i]]
accuracy = len(correct) / len(res)

print("화소 특징을 사용했을 때 정확률 =", accuracy * 100, "%")
