from sklearn import svm
from sklearn.datasets import load_iris  # 사이킷 런에서 붓 꽃 데이터셋 로드

iris = load_iris()
s = svm.SVC(gamma=0.1, C=10)  # 모델 선정

s.fit(iris.data, iris.target)  # 훈련

new_d = [[6.4, 3.2, 6.0, 2.5], [7.1, 3.1, 4.7, 1.35]]

res = s.predict(new_d)  # 예측

resultList = [res]

for i in res:
    if i == 0:
        print("품종은 setosa입니다.")
    elif i == 1:
        print("품종은 versicolor입니다.")
    elif i == 2:
        print("품종은 virginica입니다.")
    else:
        print("알 수 없는 품종입니다.")
