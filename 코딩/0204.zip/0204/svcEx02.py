import matplotlib
import plotly.express as px

# iris 데이터셋 불러오기
df = px.data.iris()

# petal_length를 제외하여 3차원 공간 구성
fig = px.scatter_3d(
    df, x="sepal_length", y="sepal_width", z="petal_width", color="species"
)

# 브라우저에서 출력
fig.show(renderer="browser")
